const currency = new Intl.NumberFormat('en-MY', { style: 'currency', currency: 'MYR', maximumFractionDigits: 0 });
const percent = new Intl.NumberFormat('en-MY', { maximumFractionDigits: 2 });

export function estimate({ revenue, profit, lostSales, contribution, waste, turnover, recovery, investment }) {
  const salesLoss = lostSales * contribution / 100;
  const loss = salesLoss + waste + turnover;
  const monthly = loss * recovery / 100 - investment;
  const projectedProfit = profit + monthly;
  const projectedRevenue = revenue + lostSales * recovery / 100;
  return {
    salesLoss, loss, monthly, annual: monthly * 12, projectedProfit,
    currentMargin: profit / revenue * 100,
    projectedMargin: projectedProfit / projectedRevenue * 100
  };
}

if (typeof document !== 'undefined') {
  const form = document.querySelector('#calculator-form');
  const results = document.querySelector('#results');
  const presets = form.querySelectorAll('[data-rate]');
  const feedback = document.querySelector('#calc-message');
  const set = (id, value) => { document.getElementById(id).textContent = value; };

  function update() {
    const values = Object.fromEntries(Array.from(form.elements)
      .filter(element => element.name)
      .map(element => [element.name, element.valueAsNumber]));
    presets.forEach(button => button.setAttribute('aria-pressed', String(Number(button.dataset.rate) === values.recovery)));
    if (!form.checkValidity()) {
      results.dataset.state = 'invalid';
      feedback.textContent = '请检查输入，测算将自动更新。';
      return;
    }
    const outcome = estimate(values);
    results.dataset.state = 'ready';
    set('loss', currency.format(outcome.loss));
    set('sales-loss', currency.format(outcome.salesLoss));
    set('waste-loss', currency.format(values.waste));
    set('turnover-loss', currency.format(values.turnover));
    set('monthly', currency.format(outcome.monthly));
    set('annual', currency.format(outcome.annual));
    set('projected', currency.format(outcome.projectedProfit));
    set('margin', percent.format(outcome.projectedMargin) + '%');
    const change = outcome.projectedMargin - outcome.currentMargin;
    set('comparison', '当前利润率 ' + percent.format(outcome.currentMargin) + '% · 变化 ' +
      (change > 0 ? '+' : '') + percent.format(change) + ' 个百分点');
    feedback.textContent = outcome.monthly < 0
      ? '在此情境下，预计挽回的利润低于改善成本。' : '';
  }

  form.addEventListener('input', update);
  form.addEventListener('reset', () => requestAnimationFrame(update));
  form.addEventListener('submit', event => {
    event.preventDefault();
    update();
    results.focus();
  });
  presets.forEach(button => button.addEventListener('click', () => {
    form.elements.recovery.value = button.dataset.rate;
    update();
  }));
  update();
}
